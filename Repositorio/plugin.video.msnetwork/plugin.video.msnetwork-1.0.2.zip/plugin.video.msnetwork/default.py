# -*- coding: utf-8 -*-
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.msnetwork'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID1 = "UC0LdsMFyFC8No4FG9atGEYA"
YOUTUBE_CHANNEL_ID2 = "PeasoGamer"

# Entry point
def run():
    plugintools.log("msnetwork.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("msnetwork.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Electric cars and the future",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail=icon,
        folder=True )
		
	plugintools.add_item( 
        #action="", 
        title="Electric cars and the future",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail=icon,
        folder=True )

run()